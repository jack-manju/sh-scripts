###This playbook will create an IAM Group

###Variables
```
iam_group
```
