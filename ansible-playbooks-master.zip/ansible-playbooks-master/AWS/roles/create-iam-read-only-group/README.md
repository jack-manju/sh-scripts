###This playbook will create an IAM Group as Read-Only with only READ-ONLY access
