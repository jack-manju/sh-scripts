###Set admin password
```
asadmin --host localhost --port 4848 change-admin-password
```
###Start admin
```
asadmin --host localhost --port 4848 enable-secure-admin
```
