Requires a database and a database user
