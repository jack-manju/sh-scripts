# This role installs nginx with naxsi in learning mode

Wiki - https://github.com/nbs-system/naxsi/wiki
