# Referring
https://www.digitalocean.com/community/tutorials/how-to-install-linotp-on-an-ubuntu-vps
