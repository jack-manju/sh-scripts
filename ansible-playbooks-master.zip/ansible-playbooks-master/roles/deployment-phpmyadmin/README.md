###Variables
```
#phpmyadmin
phpmyadmin_version : phpMyAdmin-4.4.15-english
phpmyadmin_url : https://files.phpmyadmin.net/phpMyAdmin/4.4.15/phpMyAdmin-4.4.15-english.zip
```
