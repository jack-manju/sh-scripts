Good links
https://medium.com/@harshan.dll/jenkins-automatically-rescheduling-failed-builds-with-naginator-plugin-cb4d3b273692
