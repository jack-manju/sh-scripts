Need to run to install and configure freeipa
```ipa-server-install```

Webui can be found at http://www.freeipa.org/page/Web_UI
