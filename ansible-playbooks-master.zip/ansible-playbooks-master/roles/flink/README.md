Running a flink job
```
bin/flink run examples/batch/WordCount.jar -input /tmp/input.txt -output /tmp/output.txt
```
