Need to run to install and configure freeipa
```ipa-client-install -N --hostname hostname.freeipa-domain-name --mkhomedir```

More info
http://askubuntu.com/questions/295075/freeipa-client-on-ubuntu
